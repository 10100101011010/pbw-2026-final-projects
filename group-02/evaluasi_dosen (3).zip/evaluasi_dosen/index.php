<?php
session_start();
require 'db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = MD5(trim($_POST['password']));
    $role     = $_POST['role'];

    if ($role == 'mahasiswa') {
        $sql = "SELECT * FROM mahasiswa WHERE npm = '$username' AND password = '$password'";
        $res = mysqli_query($conn, $sql);
        if (mysqli_num_rows($res) > 0) {
            $data = mysqli_fetch_assoc($res);
            $_SESSION['user_id']   = $data['id'];
            $_SESSION['user_nama'] = $data['nama'];
            $_SESSION['role']      = 'mahasiswa';
            $_SESSION['kelas_id']  = $data['kelas_id'];
            
            header("Location: mahasiswa/dashboard.php");
            exit();
        } else {
            $error = "NPM atau password salah.";
        }
    } elseif ($role == 'admin') {
        $sql = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
        $res = mysqli_query($conn, $sql);
        if (mysqli_num_rows($res) > 0) {
            $data = mysqli_fetch_assoc($res);
            $_SESSION['user_id']   = $data['id'];
            $_SESSION['user_nama'] = $data['nama'];
            $_SESSION['role']      = 'admin';
            header("Location: admin/dashboard.php");
            exit();
        } else {
            $error = "Username atau password salah.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Evaluasi Dosen - Universitas Gunadarma</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            background: #0a0a0a;
        }

        .login-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            background: url('assets/gedung.jpg') center/cover no-repeat fixed;
        }

        .login-wrapper::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            pointer-events: none;
        }

        .login-container {
            display: flex;
            max-width: 1000px;
            width: 100%;
            min-height: 560px;
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.4);
            position: relative;
            z-index: 1;
            border: 1px solid rgba(255, 255, 255, 0.15);
        }

        /* Left Panel - Branding (transparan) */
        .brand-panel {
            flex: 1;
            padding: 50px 40px;
            background: rgba(74, 21, 75, 0.5);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            position: relative;
            overflow: hidden;
            border-right: 1px solid rgba(255, 255, 255, 0.08);
        }

        .brand-panel::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
            border-radius: 50%;
        }

        .brand-panel .brand-icon {
            width: 95px;
            height: 95px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 28px;
            position: relative;
            border: 3px solid rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
        }

        .brand-panel .brand-icon img {
            width: 75px;
            height: 75px;
            border-radius: 50%;
            object-fit: cover;
        }

        .brand-panel h1 {
            color: white;
            font-size: 22px;
            font-weight: 800;
            letter-spacing: 2px;
            margin-bottom: 6px;
            position: relative;
            text-shadow: 0 2px 20px rgba(0,0,0,0.3);
        }

        .brand-panel .subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 12px;
            letter-spacing: 3px;
            font-weight: 300;
            position: relative;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .brand-panel .decor-line {
            width: 50px;
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            margin: 16px auto 0;
            border-radius: 2px;
            position: relative;
        }

        /* DISCLAIMER - Tambahan baru */
        .brand-panel .disclaimer {
            margin-top: 20px;
            padding: 12px 16px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.06);
            position: relative;
            max-width: 90%;
        }

        .brand-panel .disclaimer p {
            color: rgba(255, 255, 255, 0.6);
            font-size: 10px;
            line-height: 1.6;
            letter-spacing: 0.5px;
            font-weight: 300;
            font-style: italic;
        }

        .brand-panel .disclaimer p .highlight {
            color: rgba(255, 215, 0, 0.7);
            font-weight: 400;
        }

        .brand-panel .disclaimer .quote-icon {
            color: rgba(255, 255, 255, 0.2);
            font-size: 16px;
            line-height: 1;
        }

        /* Right Panel - Form (transparan) */
        .form-panel {
            flex: 1;
            padding: 50px 45px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }

        .form-panel .form-header {
            margin-bottom: 30px;
        }

        .form-panel .form-header h2 {
            color: white;
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 4px;
            text-shadow: 0 2px 20px rgba(0,0,0,0.3);
        }

        .form-panel .form-header p {
            color: rgba(255, 255, 255, 0.7);
            font-size: 13px;
            font-weight: 400;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 5px;
        }

        .form-group label .required {
            color: #ff6b6b;
            margin-left: 2px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 13px 16px;
            border: 2px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(5px);
            color: white;
            font-family: 'Inter', sans-serif;
        }

        .form-group input::placeholder {
            color: rgba(255, 255, 255, 0.4);
            font-weight: 300;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: rgba(255, 255, 255, 0.5);
            background: rgba(255, 255, 255, 0.15);
            outline: none;
            box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.05);
        }

        .form-group select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23ffffff' stroke-width='2' fill='none' opacity='0.5'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 16px center;
            cursor: pointer;
            color: white;
        }

        .form-group select option {
            background: #2d1b2e;
            color: white;
        }

        .error-message {
            background: rgba(255, 0, 0, 0.15);
            backdrop-filter: blur(10px);
            color: #ff6b6b;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 13px;
            margin-bottom: 18px;
            border-left: 4px solid #ff6b6b;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .error-message::before {
            content: '⚠';
            font-size: 16px;
        }

        .btn-login {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, rgba(74, 21, 75, 0.9), rgba(107, 32, 109, 0.9));
            backdrop-filter: blur(10px);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 8px;
            transition: all 0.3s ease;
            letter-spacing: 1px;
            font-family: 'Inter', sans-serif;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(74, 21, 75, 0.4);
            background: linear-gradient(135deg, rgba(74, 21, 75, 0.95), rgba(107, 32, 109, 0.95));
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .form-footer {
            margin-top: 22px;
            text-align: center;
            padding-top: 18px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .form-footer .signup-text {
            color: rgba(255, 255, 255, 0.6);
            font-size: 13px;
        }

        .form-footer .signup-text a {
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .form-footer .signup-text a:hover {
            color: white;
            text-decoration: underline;
        }

        /* Demo Info - transparan */
        .demo-info {
            margin-top: 16px;
            padding: 14px 18px;
            background: rgba(255, 255, 255, 0.06);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .demo-info .demo-title {
            font-size: 11px;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.7);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 6px;
        }

        .demo-info .demo-row {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 3px 0;
            font-size: 12px;
            color: rgba(255, 255, 255, 0.7);
        }

        .demo-info .demo-row .badge {
            display: inline-block;
            padding: 1px 10px;
            border-radius: 10px;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-admin {
            background: rgba(74, 21, 75, 0.8);
            color: white;
        }

        .badge-mahasiswa {
            background: rgba(107, 32, 109, 0.8);
            color: white;
        }

        .demo-info .demo-row .user {
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
        }

        .demo-info .demo-row .pass {
            color: rgba(255, 255, 255, 0.4);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                min-height: auto;
                border-radius: 20px;
            }

            .brand-panel {
                padding: 35px 30px;
                min-height: 180px;
                border-right: none;
                border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            }

            .brand-panel .brand-icon {
                width: 70px;
                height: 70px;
                margin-bottom: 18px;
            }

            .brand-panel .brand-icon img {
                width: 55px;
                height: 55px;
            }

            .brand-panel h1 {
                font-size: 18px;
            }

            .brand-panel .subtitle {
                font-size: 10px;
                letter-spacing: 2px;
            }

            .brand-panel .disclaimer p {
                font-size: 9px;
            }

            .form-panel {
                padding: 30px 25px;
            }

            .form-panel .form-header h2 {
                font-size: 22px;
            }
        }

        @media (max-width: 480px) {
            .login-wrapper {
                padding: 10px;
            }

            .form-panel {
                padding: 22px 16px;
            }

            .brand-panel {
                padding: 25px 20px;
                min-height: 150px;
            }

            .brand-panel .brand-icon {
                width: 60px;
                height: 60px;
                margin-bottom: 14px;
            }

            .brand-panel .brand-icon img {
                width: 45px;
                height: 45px;
            }

            .brand-panel h1 {
                font-size: 16px;
            }

            .brand-panel .subtitle {
                font-size: 9px;
            }

            .brand-panel .disclaimer {
                padding: 10px 12px;
                margin-top: 14px;
            }

            .brand-panel .disclaimer p {
                font-size: 8px;
            }

            .form-panel .form-header h2 {
                font-size: 20px;
            }

            .form-group input,
            .form-group select {
                padding: 11px 14px;
                font-size: 13px;
            }

            .btn-login {
                padding: 13px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-container">
            <!-- Left Panel - Branding -->
            <div class="brand-panel">
                <div class="brand-icon">
                    <img src="assets/gunadarma.png" alt="Gunadarma">
                </div>
                <h1>Portal Evaluasi</h1>
                <p class="subtitle">UNIVERSITAS GUNADARMA</p>
                <div class="decor-line"></div>

                <!-- DISCLAIMER --->
                <div class="disclaimer">
                    <p>
                        <span class="quote-icon">"</span>
                        <span class="highlight">Bijak dalam memberikan evaluasi</span> 
                        adalah cerminan integritas dan kepedulian kita terhadap kualitas pendidikan. 
                        Setiap penilaian yang objektif dan konstruktif akan menjadi fondasi 
                        bagi terciptanya lingkungan akademik yang <span class="highlight">bermartabat</span> 
                        dan <span class="highlight">berkelanjutan</span>.
                        <span class="quote-icon">"</span>
                    </p>
                </div>
            </div>

            <!-- Right Panel - Form -->
            <div class="form-panel">
                <div class="form-header">
                    <h2>Sign In</h2>
                    <p>Masuk ke akun Anda</p>
                </div>

                <?php if ($error): ?>
                    <div class="error-message"> <?= $error ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="form-group">
                        <label>Login Sebagai</label>
                        <select name="role">
                            <option value="mahasiswa">Mahasiswa</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>NPM / Username <span class="required">*</span></label>
                        <input type="text" name="username" placeholder="11124084" value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Password <span class="required">*</span></label>
                        <input type="password" name="password" placeholder="••••••••" required>
                    </div>

                    <button type="submit" class="btn-login">MASUK</button>
                </form>

            
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>